---
layout: post
title: Dog versus Cats (Kaggle Competition) - My solution
comments: true
date: 2017-25-03
tags: Machine-Learning Classification supervised Learning Kaggle Keras sk-learn
intro: ""
categories: MachineDeepLearning
---


Improve performance with Data
* get more data
* get new data
* rescale data
* Transform data


Data augmentation : generative model randomly shift rotate
We are adding noise/jitter - can act like a regularization method to curb overfitting