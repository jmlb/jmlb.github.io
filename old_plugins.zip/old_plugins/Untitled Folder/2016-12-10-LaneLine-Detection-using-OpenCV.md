---
layout: post
title: Lane Line Detection using OpenCV
comments: true
date: 2016-12-10
tags: SDCND Self-Driving-Car-Nanodegree Udacity 
categories: MachineDeepLearning SDCND
img_post: post_dockerRos_title.png
github-link: "https://github.com/jmlb/MacOS-Container4Ros-SDCND"
---

The first assignment of the Self Driving Car Nanodegree.
The pipeline includes a few steps:

image
gaussian blur 

canny edge

etc...


explain each step

You can find my implementation here.

check also my own videos.