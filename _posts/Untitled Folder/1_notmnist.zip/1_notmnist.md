
Deep Learning
=============

Assignment 1
------------

The objective of this assignment is to learn about simple data curation practices, and familiarize you with some of the data we'll be reusing later.

This notebook uses the [notMNIST](http://yaroslavvb.blogspot.com/2011/09/notmnist-dataset.html) dataset to be used with python experiments. This dataset is designed to look like the classic [MNIST](http://yann.lecun.com/exdb/mnist/) dataset, while looking a little more like real data: it's a harder task, and the data is a lot less 'clean' than MNIST.


```python
# These are all the modules we'll be using later. Make sure you can import them
# before proceeding further.
from __future__ import print_function
import matplotlib.pyplot as plt
import numpy as np
import os
import sys
import tarfile
from IPython.display import display, Image, FileLink
from scipy import ndimage
from sklearn.linear_model import LogisticRegression
from six.moves.urllib.request import urlretrieve
from six.moves import cPickle as pickle

# Config the matlotlib backend as plotting inline in IPython
%matplotlib inline
```

First, we'll download the dataset to our local machine. The data consists of characters rendered in a variety of fonts on a 28x28 image. The labels are limited to 'A' through 'J' (10 classes). The training set has about 500k and the testset 19000 labelled examples. Given these sizes, it should be possible to train models quickly on any machine.


```python
url = 'http://commondatastorage.googleapis.com/books1000/'
last_percent_reported = None

def download_progress_hook(count, blockSize, totalSize):
  """A hook to report the progress of a download. This is mostly intended for users with
  slow internet connections. Reports every 1% change in download progress.
  """
  global last_percent_reported
  percent = int(count * blockSize * 100 / totalSize)

  if last_percent_reported != percent:
    if percent % 5 == 0:
      sys.stdout.write("%s%%" % percent)
      sys.stdout.flush()
    else:
      sys.stdout.write(".")
      sys.stdout.flush()
      
    last_percent_reported = percent
        
def maybe_download(filename, expected_bytes, force=False):
  """Download a file if not present, and make sure it's the right size."""
  if force or not os.path.exists(filename):
    print('Attempting to download:', filename) 
    filename, _ = urlretrieve(url + filename, filename, reporthook=download_progress_hook)
    print('\nDownload Complete!')
  statinfo = os.stat(filename)
  if statinfo.st_size == expected_bytes:
    print('Found and verified', filename)
  else:
    raise Exception(
      'Failed to verify ' + filename + '. Can you get to it with a browser?')
  return filename

train_filename = maybe_download('notMNIST_large.tar.gz', 247336696)
test_filename = maybe_download('notMNIST_small.tar.gz', 8458043)
```

    Attempting to download: notMNIST_large.tar.gz
    0%....5%....10%....15%....20%....25%....30%....35%....40%....45%....50%....55%....60%....65%....70%....75%....80%....85%....90%....95%....100%
    Download Complete!
    Found and verified notMNIST_large.tar.gz
    Attempting to download: notMNIST_small.tar.gz
    0%....5%....10%....15%....20%....25%....30%....35%....40%....45%....50%....55%....60%....65%....70%....75%....80%....85%....90%....95%....100%
    Download Complete!
    Found and verified notMNIST_small.tar.gz


Extract the dataset from the compressed .tar.gz file.
This should give you a set of directories, labelled A through J.


```python
num_classes = 10
np.random.seed(133)

def maybe_extract(filename, force=False):
  root = os.path.splitext(os.path.splitext(filename)[0])[0]  # remove .tar.gz
  if os.path.isdir(root) and not force:
    # You may override by setting force=True.
    print('%s already present - Skipping extraction of %s.' % (root, filename))
  else:
    print('Extracting data for %s. This may take a while. Please wait.' % root)
    tar = tarfile.open(filename)
    sys.stdout.flush()
    tar.extractall()
    tar.close()
  data_folders = [
    os.path.join(root, d) for d in sorted(os.listdir(root))
    if os.path.isdir(os.path.join(root, d))]
  if len(data_folders) != num_classes:
    raise Exception(
      'Expected %d folders, one per class. Found %d instead.' % (
        num_classes, len(data_folders)))
  print(data_folders)
  return data_folders
  
train_folders = maybe_extract(train_filename)
test_folders = maybe_extract(test_filename)
```

    notMNIST_large already present - Skipping extraction of notMNIST_large.tar.gz.
    ['notMNIST_large/A', 'notMNIST_large/B', 'notMNIST_large/C', 'notMNIST_large/D', 'notMNIST_large/E', 'notMNIST_large/F', 'notMNIST_large/G', 'notMNIST_large/H', 'notMNIST_large/I', 'notMNIST_large/J']
    notMNIST_small already present - Skipping extraction of notMNIST_small.tar.gz.
    ['notMNIST_small/A', 'notMNIST_small/B', 'notMNIST_small/C', 'notMNIST_small/D', 'notMNIST_small/E', 'notMNIST_small/F', 'notMNIST_small/G', 'notMNIST_small/H', 'notMNIST_small/I', 'notMNIST_small/J']


---
Problem 1
---------

Let's take a peek at some of the data to make sure it looks sensible. Each exemplar should be an image of a character A through J rendered in a different font. Display a sample of the images that we just downloaded. Hint: you can use the package IPython.display.




```python
Image("notMNIST_large/J/a2VhZ2FuLnR0Zg==.png")
```




![png](output_7_0.png)



Now let's load the data in a more manageable format. Since, depending on your computer setup you might not be able to fit it all in memory, we'll load each class into a separate dataset, store them on disk and curate them independently. Later we'll merge them into a single dataset of manageable size.

We'll convert the entire dataset into a 3D array (image index, x, y) of floating point values, normalized to have approximately zero mean and standard deviation ~0.5 to make training easier down the road. 

A few images might not be readable, we'll just skip them.


```python
image_size = 28  # Pixel width and height.
pixel_depth = 255.0  # Number of levels per pixel.

def load_letter(folder, min_num_images):
  """Load the data for a single letter label."""
  image_files = os.listdir(folder)
  dataset = np.ndarray(shape=(len(image_files), image_size, image_size),
                         dtype=np.float32)
  print(folder)
  num_images = 0
  for image in image_files:
    image_file = os.path.join(folder, image)
    try:
      image_data = (ndimage.imread(image_file).astype(float) - 
                    pixel_depth / 2) / pixel_depth
      if image_data.shape != (image_size, image_size):
        raise Exception('Unexpected image shape: %s' % str(image_data.shape))
      dataset[num_images, :, :] = image_data
      num_images = num_images + 1
    except IOError as e:
      print('Could not read:', image_file, ':', e, '- it\'s ok, skipping.')
    
  dataset = dataset[0:num_images, :, :]
  if num_images < min_num_images:
    raise Exception('Many fewer images than expected: %d < %d' %
                    (num_images, min_num_images))
    
  print('Full dataset tensor:', dataset.shape)
  print('Mean:', np.mean(dataset))
  print('Standard deviation:', np.std(dataset))
  return dataset
        
def maybe_pickle(data_folders, min_num_images_per_class, force=False):
  dataset_names = []
  for folder in data_folders:
    set_filename = folder + '.pickle'
    dataset_names.append(set_filename)
    if os.path.exists(set_filename) and not force:
      # You may override by setting force=True.
      print('%s already present - Skipping pickling.' % set_filename)
    else:
      print('Pickling %s.' % set_filename)
      dataset = load_letter(folder, min_num_images_per_class)
      print(dataset)
      try:
        with open(set_filename, 'wb') as f:
          pickle.dump(dataset, f, pickle.HIGHEST_PROTOCOL)
      except Exception as e:
        print('Unable to save data to', set_filename, ':', e)
  
  return dataset_names

train_datasets = maybe_pickle(train_folders, 45000)
test_datasets = maybe_pickle(test_folders, 1800)
```

    notMNIST_large/A.pickle already present - Skipping pickling.
    notMNIST_large/B.pickle already present - Skipping pickling.
    notMNIST_large/C.pickle already present - Skipping pickling.
    notMNIST_large/D.pickle already present - Skipping pickling.
    notMNIST_large/E.pickle already present - Skipping pickling.
    notMNIST_large/F.pickle already present - Skipping pickling.
    notMNIST_large/G.pickle already present - Skipping pickling.
    notMNIST_large/H.pickle already present - Skipping pickling.
    notMNIST_large/I.pickle already present - Skipping pickling.
    notMNIST_large/J.pickle already present - Skipping pickling.
    notMNIST_small/A.pickle already present - Skipping pickling.
    notMNIST_small/B.pickle already present - Skipping pickling.
    notMNIST_small/C.pickle already present - Skipping pickling.
    notMNIST_small/D.pickle already present - Skipping pickling.
    notMNIST_small/E.pickle already present - Skipping pickling.
    notMNIST_small/F.pickle already present - Skipping pickling.
    notMNIST_small/G.pickle already present - Skipping pickling.
    notMNIST_small/H.pickle already present - Skipping pickling.
    notMNIST_small/I.pickle already present - Skipping pickling.
    notMNIST_small/J.pickle already present - Skipping pickling.


---
Problem 2
---------

Let's verify that the data still looks good. Displaying a sample of the labels and images from the ndarray. Hint: you can use matplotlib.pyplot.

---


```python
f=open("notMNIST_large/C.pickle", 'rb')
img = pickle.load(f)
print(type(img))
plt.imshow(img[18,:,:])
```

    <class 'numpy.ndarray'>





    <matplotlib.image.AxesImage at 0x1121f0358>




![png](output_11_2.png)


---
Problem 3
---------
Another check: we expect the data to be balanced across classes. Verify that.

---


```python
letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
for letter in letters:
    f=open("notMNIST_large/"+letter+".pickle", 'rb')
    set_imgs = pickle.load(f)
    print("Number of examples for letter {}: {} \n".format(letter, set_imgs.shape[0]))
```

    Number of examples for letter A: 52909 
    
    Number of examples for letter B: 52911 
    
    Number of examples for letter C: 52912 
    
    Number of examples for letter D: 52911 
    
    Number of examples for letter E: 52912 
    
    Number of examples for letter F: 52912 
    
    Number of examples for letter G: 52912 
    
    Number of examples for letter H: 52912 
    
    Number of examples for letter I: 52912 
    
    Number of examples for letter J: 52911 
    


Merge and prune the training data as needed. Depending on your computer setup, you might not be able to fit it all in memory, and you can tune `train_size` as needed. The labels will be stored into a separate array of integers 0 through 9.

Also create a validation dataset for hyperparameter tuning.


```python
def make_arrays(nb_rows, img_size):
  if nb_rows:
    dataset = np.ndarray((nb_rows, img_size, img_size), dtype=np.float32)
    labels = np.ndarray(nb_rows, dtype=np.int32)
  else:
    dataset, labels = None, None
  return dataset, labels

def merge_datasets(pickle_files, train_size, valid_size=0):
  num_classes = len(pickle_files)
  valid_dataset, valid_labels = make_arrays(valid_size, image_size)
  train_dataset, train_labels = make_arrays(train_size, image_size)
  vsize_per_class = valid_size // num_classes
  tsize_per_class = train_size // num_classes
    
  start_v, start_t = 0, 0
  end_v, end_t = vsize_per_class, tsize_per_class
  end_l = vsize_per_class+tsize_per_class
  for label, pickle_file in enumerate(pickle_files):       
    try:
      with open(pickle_file, 'rb') as f:
        letter_set = pickle.load(f)
        # let's shuffle the letters to have random validation and training set
        np.random.shuffle(letter_set)
        if valid_dataset is not None:
          valid_letter = letter_set[:vsize_per_class, :, :]
          valid_dataset[start_v:end_v, :, :] = valid_letter
          valid_labels[start_v:end_v] = label
          start_v += vsize_per_class
          end_v += vsize_per_class
                    
        train_letter = letter_set[vsize_per_class:end_l, :, :]
        train_dataset[start_t:end_t, :, :] = train_letter
        train_labels[start_t:end_t] = label
        start_t += tsize_per_class
        end_t += tsize_per_class
    except Exception as e:
      print('Unable to process data from', pickle_file, ':', e)
      raise
    
  return valid_dataset, valid_labels, train_dataset, train_labels
            
            
train_size = 200000
valid_size = 10000
test_size = 10000

valid_dataset, valid_labels, train_dataset, train_labels = merge_datasets(train_datasets, train_size, valid_size)
_, _, test_dataset, test_labels = merge_datasets(test_datasets, test_size)

print('Training:', train_dataset.shape, train_labels.shape)
print('Validation:', valid_dataset.shape, valid_labels.shape)
print('Testing:', test_dataset.shape, test_labels.shape)
```

    Training: (200000, 28, 28) (200000,)
    Validation: (10000, 28, 28) (10000,)
    Testing: (10000, 28, 28) (10000,)


Next, we'll randomize the data. It's important to have the labels well shuffled for the training and test distributions to match.


```python
def randomize(dataset, labels):
  permutation = np.random.permutation(labels.shape[0])
  shuffled_dataset = dataset[permutation,:,:]
  shuffled_labels = labels[permutation]
  return shuffled_dataset, shuffled_labels
train_dataset, train_labels = randomize(train_dataset, train_labels)
test_dataset, test_labels = randomize(test_dataset, test_labels)
valid_dataset, valid_labels = randomize(valid_dataset, valid_labels)
```

---
Problem 4
---------
Convince yourself that the data is still good after shuffling!

---

Finally, let's save the data for later reuse:


```python
pickle_file = 'notMNIST2.pickle'

try:
  f = open(pickle_file, 'wb')
  save = {
    'train_dataset': train_dataset,
    'train_labels': train_labels,
    'valid_dataset': valid_dataset,
    'valid_labels': valid_labels,
    'test_dataset': test_dataset,
    'test_labels': test_labels,
    }
  pickle.dump(save, f, protocol=2)
  #pickle.dump(save, f, pickle.HIGHEST_PROTOCOL)
  f.close()
except Exception as e:
  print('Unable to save data to', pickle_file, ':', e)
  raise
```


```python
statinfo = os.stat(pickle_file)
print('Compressed pickle size:', statinfo.st_size)
```

    Compressed pickle size: 988107205


---
Problem 5
---------

By construction, this dataset might contain a lot of overlapping samples, including training data that's also contained in the validation and test set! Overlap between training and test can skew the results if you expect to use your model in an environment where there is never an overlap, but are actually ok if you expect to see training samples recur when you use it.
Measure how much overlap there is between training, validation and test samples.

Optional questions:
- What about near duplicates between datasets? (images that are almost identical)
- Create a sanitized validation and test set, and compare your accuracy on those in subsequent assignments.
---


```python
#this solution was provided on:
#https://discussions.udacity.com/t/assignment-1-problem-5/45657/63
#I chnged the has function to md5 to gain a few seconds in running time
import time
import hashlib
t1 = time.time()

train_hashes = [hashlib.md5(x).digest() for x in train_dataset]
valid_hashes = [hashlib.md5(x).digest() for x in valid_dataset]
test_hashes  = [hashlib.md5(x).digest() for x in test_dataset]

valid_in_train = np.in1d(valid_hashes, train_hashes) #0 if diff or 1 if ==
test_in_train  = np.in1d(test_hashes,  train_hashes)
test_in_valid  = np.in1d(test_hashes,  valid_hashes)

valid_keep = ~valid_in_train #~ bit-wise inversion change True to False
test_keep  = ~(test_in_train | test_in_valid) # | "bitwise or". 0 if bit of x AND y is 0, otherwise 1.

valid_dataset_clean = valid_dataset[valid_keep]
valid_labels_clean  = valid_labels [valid_keep]

test_dataset_clean = test_dataset[test_keep]
test_labels_clean  = test_labels [test_keep]

t2 = time.time()

print("Time: %0.2fs" % (t2 - t1))
print("valid -> train overlap: %d samples" % valid_in_train.sum())
print("test  -> train overlap: %d samples" % test_in_train.sum())
print("test  -> valid overlap: %d samples" % test_in_valid.sum())
```

    Time: 2.01s
    valid -> train overlap: 1067 samples
    test  -> train overlap: 1324 samples
    test  -> valid overlap: 200 samples



```python
print(train_labels[2050])
```

    9


---
Problem 6
---------

Let's get an idea of what an off-the-shelf classifier can give you on this data. It's always good to check that there is something to learn, and that it's a problem that is not so trivial that a canned solution solves it.

Train a simple model on this data using 50, 100, 1000 and 5000 training samples. Hint: you can use the LogisticRegression model from sklearn.linear_model.

Optional question: train an off-the-shelf model on all the data!

---


```python
#Check that each set of training data, has same number of 
for i in range(10):
    same_class_exples = np.sum(train_labels == i)
    print('Number of train examples of class %d: %d' % (i, same_class_exples))
```

    Number of train examples of class 0: 20000
    Number of train examples of class 1: 20000
    Number of train examples of class 2: 20000
    Number of train examples of class 3: 20000
    Number of train examples of class 4: 20000
    Number of train examples of class 5: 20000
    Number of train examples of class 6: 20000
    Number of train examples of class 7: 20000
    Number of train examples of class 8: 20000
    Number of train examples of class 9: 20000



```python
logreg = LogisticRegression()

#fit training data
#flatten 3D matrix (2D)
train_dataset_flat = np.reshape(train_dataset,(train_dataset.shape[0], image_size*image_size))
valid_dataset_flat = np.reshape(valid_dataset,(valid_dataset.shape[0], image_size*image_size))
test_dataset_flat = np.reshape(test_dataset,(test_dataset.shape[0], image_size*image_size))

# we create an instance of Neighbours Classifier and fit the data.
ls_nbr_train_samples = [50,100,1000, 5000, 10000,20000]
accuracy_hist = np.zeros((len(ls_nbr_train_samples),3))
#do one-vs-all training out of the box.

compute_time = np.zeros((len(ls_nbr_train_samples),2))
for idx, sample_size in enumerate(ls_nbr_train_samples):
    start_time = time.time()
    logreg.fit(train_dataset_flat[0:sample_size,:], train_labels[0:sample_size])
    compute_time[idx,:] = [sample_size, time.time() - start_time]
    train_predict = logreg.predict(train_dataset_flat[0:sample_size,:])
    train_accuracy = (np.sum(train_predict == train_labels[0:sample_size])*1.0)/sample_size
    print('Accuracy Training data :', train_accuracy)
    valid_predict = logreg.predict(valid_dataset_flat)
    valid_accuracy = (np.sum(valid_predict == valid_labels)*1.0)/test_labels.shape[0]
    print('Accuracy Validation data:', valid_accuracy)
    accuracy_hist[idx,:] = [sample_size, 1-train_accuracy, 1-valid_accuracy ]
```

    Accuracy Training data : 1.0
    Accuracy Validation data: 0.4649
    Accuracy Training data : 1.0
    Accuracy Validation data: 0.6322
    Accuracy Training data : 0.997
    Accuracy Validation data: 0.7577
    Accuracy Training data : 0.949
    Accuracy Validation data: 0.7757
    Accuracy Training data : 0.9029
    Accuracy Validation data: 0.7896
    Accuracy Training data : 0.86745
    Accuracy Validation data: 0.801



```python
# Plot error versus Nbr of train samples used for training
plt.figure(1)
plt.plot(accuracy_hist[:,0], accuracy_hist[:,1], 'ro')
plt.plot(accuracy_hist[:,0], accuracy_hist[:,2], 'bo')
plt.title('Logistic Regression NotMNIST')
plt.xlabel('Training Data Size (# of examples)')
plt.ylabel('Classification Error')

#Scaling Batch Gradient Descent
plt.figure(2)
plt.plot(compute_time[:,0], compute_time[:,1], 'ro')
plt.title('Computing Time vs. Training set size')
plt.xlabel('Training Data Size (# of examples)')
plt.ylabel('Computing Time')
```




    <matplotlib.text.Text at 0x116c5de80>




![png](output_28_1.png)



![png](output_28_2.png)



```python
#50000 samples woudl be good enough to achieve good classification performance, beyoond that, the classification error is practically unchanged.
#converging towards 17-18%
#Classification Error on a 
test_predict = logreg.predict(test_dataset_flat)
test_accuracy = (np.sum(test_predict == test_labels)*1.0)/valid_labels.shape[0]
print('Classification Error on test dataset (train_data size = %d examples): %.3f' %(sample_size, test_accuracy))
```

    Classification Error on test dataset (train_data size = 20000 examples): 0.875



```python
#Stochastic gradient descent:
from sklearn.linear_model import SGDClassifier
sgd_model = SGDClassifier(loss="log", n_iter=1000, alpha=0.1, fit_intercept=True, warm_start=True, learning_rate='optimal')

step =500
batches= np.arange(0,train_labels.shape[0],step)
all_classes = np.unique(train_labels)
classifier = SGDClassifier()
hist_score = np.zeros((batches.shape[0], 2))
for idx, curr in enumerate(batches):
    if idx == 0:
        sgd_model.fit(train_dataset_flat[curr:curr+step,:], train_labels[curr:curr+step])
    else:
         sgd_model.partial_fit(train_dataset_flat[curr:curr+step,:], train_labels[curr:curr+step])
    score= sgd_model.score(train_dataset_flat[curr:curr+step,:], train_labels[curr:curr+step])
    hist_score[idx,:] = [curr, score]

plt.figure(3)
plt.plot(hist_score[:,0], hist_score[:,1], 'b-')
plt.plot([0,200000], [0.792, 0.792], 'r-')
plt.title('Score of Training set vs. batch size (SGD)')
plt.xlabel('Training Data Size (# of examples in batch)')
plt.ylabel('score')
```




    <matplotlib.text.Text at 0x116d885f8>




![png](output_30_1.png)



```python
train_sgd_predict = sgd_model.predict(train_dataset_flat)
train_sgd_accuracy = (np.sum(train_sgd_predict == train_labels)*1.0)/train_labels.shape[0]
valid_sgd_predict = sgd_model.predict(valid_dataset_flat)
valid_sgd_accuracy = (np.sum(valid_sgd_predict == valid_labels)*1.0)/test_labels.shape[0]
print("Accuracy Training data : {} | Validation data: {}".format( train_sgd_accuracy, valid_sgd_accuracy ) )
```

    Accuracy Training data : 0.79625 | Validation data: 0.792



```python

```
